sudo apt -y install cmake clang libglut-dev libglew-dev bash &> /dev/null
sleep 10s
if [ -d build/ ]
then
	cd build
else
	mkdir build && cd build
fi
chmod u+w+x ./make.sh && ./make.sh
